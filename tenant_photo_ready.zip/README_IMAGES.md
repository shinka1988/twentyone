# Twenty one サイトの写真追加ガイド

写真は `src/assets/images/` ではなく、Astro の公開用 `public/images/` に置く想定です。

推奨:
- `public/images/hero/` : TOPのメイン写真
- `public/images/salon/` : ABOUT・店内写真
- `public/images/menu/` : メニュー写真
- `public/images/gallery/` : TOPのギャラリー
- `public/images/staff/` : スタッフ写真

写真を追加したら `src/data/salon.ts` や `src/data/menu.ts` のコメント例を参考にパスを設定してください。
